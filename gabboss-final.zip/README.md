
# GABBOSS.AI - FINAL
Domain: gabboss.ai
Runway Credits: 3000 = $30

DEPLOY:
1. Push to github.com/gkksemy/gabboss-ai (new repo)
2. Vercel Import
3. Env: RUNWAY_API_KEY
4. Deploy
5. Vercel -> Domains -> Add gabboss.ai

PRICING:
FREE+ADS 30s (250cr) - ad revenue
PRO $19.99 1000cr (cost $10, profit $9.99)
PREMIUM $49.99 3000cr (cost $30, profit $19.99)

3 MIN = 18 clips x 10s stitched. Implemented in frontend loop.

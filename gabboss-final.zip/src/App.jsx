
import React, { useState, useEffect } from 'react'

export default function App(){
  const [credits, setCredits] = useState(()=> parseInt(localStorage.getItem('gabboss_credits')||'3000'))
  const [plan, setPlan] = useState(()=> localStorage.getItem('gabboss_plan')||'OWNER')
  const [tab, setTab] = useState('create')
  
  const [character, setCharacter] = useState('talking apple with gangster face')
  const [style, setStyle] = useState('realistic cinematic')
  const [emotion, setEmotion] = useState('angry cussing, emotional')
  const [action, setAction] = useState('driving a black G-Wagon in Miami wearing Gucci')
  const [voice, setVoice] = useState('deep gangster voice, singing at end')
  const [story, setStory] = useState('Two fruits argue about money in a mansion, then drive off to make more money')
  const [duration, setDuration] = useState(30)
  const [loading, setLoading] = useState(false)
  const [logs, setLogs] = useState([])
  const [videos, setVideos] = useState([])

  useEffect(()=>{
    localStorage.setItem('gabboss_credits', credits)
    localStorage.setItem('gabboss_plan', plan)
  },[credits,plan])

  const costMap = {30:250, 60:500, 120:1000, 180:1500}

  const generate = async () => {
    const cost = costMap[duration]
    if(credits < cost) return alert(`Not enough credits. Need ${cost}, you have ${credits}. Your Runway has 3000 total.`)
    
    setLoading(true)
    setLogs([`GABBOSS.AI ENGINE START`, `Character: ${character}`, `Style: ${style}`, `Emotion: ${emotion}`, `Duration: ${duration}s = ${duration/10} clips`, `Using your Runway 3000 credits...`])
    
    try{
      const res = await fetch('/api/generate', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({
          fullPrompt: `${style}, ${character}, ${action}, ${emotion}, ${voice}, story: ${story}, camera moves: cinematic drone, closeup, tracking`,
          duration,
          character, style
        })
      })
      const data = await res.json()
      setLogs(l=>[...l, `Runway Response: ${JSON.stringify(data).slice(0,200)}`, data.mock ? 'MOCK MODE: Add RUNWAY_API_KEY in Vercel to generate real' : `Clip generated, cost ${cost} credits`])
      
      const newCredits = credits - cost
      setCredits(newCredits)
      setVideos(v=>[{id:Date.now(), duration, prompt: story, cost, url: data.videoUrl || 'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4'}, ...v])
      
    }catch(e){
      setLogs(l=>[...l, `Error: ${e.message}`])
    }
    setLoading(false)
  }

  return (
    <div style={{maxWidth:1200, margin:'0 auto', padding:'20px'}}>
      <header style={{display:'flex', justifyContent:'space-between', alignItems:'center', borderBottom:'1px solid #1a1a1a', paddingBottom:20}}>
        <div><h1 style={{fontSize:28, fontWeight:900, letterSpacing:-1}}>GABBOSS<span className="gold">.AI</span></h1><p style={{fontSize:11, color:'#666', letterSpacing:2}}>REAL • CARTOON • FRUIT • HUMAN EMOTIONS</p></div>
        <div style={{display:'flex', gap:10, alignItems:'center'}}>
          <div style={{background:'#111', border:'1px solid #FFD700', padding:'8px 14px', borderRadius:30, fontSize:13}}><span className="gold">●</span> {credits} RUNWAY CREDITS LEFT</div>
          <button className="btn btn-black" onClick={()=>setTab('pricing')}>{plan}</button>
        </div>
      </header>

      <div style={{display:'flex', gap:10, margin:'20px 0'}}>
        <button onClick={()=>setTab('create')} className={`btn ${tab==='create'?'btn-gold':'btn-black'}`}>STUDIO</button>
        <button onClick={()=>setTab('videos')} className={`btn ${tab==='videos'?'btn-gold':'btn-black'}`}>MY VAULT ({videos.length})</button>
        <button onClick={()=>setTab('pricing')} className={`btn ${tab==='pricing'?'btn-gold':'btn-black'}`}>EARN MONEY</button>
      </div>

      {tab==='create' && (
        <div style={{display:'grid', gridTemplateColumns:'360px 1fr', gap:20}}>
          <div style={{display:'flex', flexDirection:'column', gap:16}}>
            <div className="card">
              <label style={{fontSize:12, color:'#FFD700'}}>1. CHARACTER (human-like)</label>
              <select value={character} onChange={e=>setCharacter(e.target.value)} style={{width:'100%', marginTop:8, padding:12, background:'#000', color:'#fff', borderRadius:10, border:'1px solid #333'}}>
                <option>realistic human man</option><option>realistic human woman</option>
                <option>cinematic actor</option><option>cartoon 3D Pixar</option>
                <option>talking apple with gangster face</option><option>talking banana boss smoking cigar</option>
                <option>talking orange girl emotional</option><option>talking strawberry couple arguing</option>
                <option>fruit mafia family</option><option>lemon & lime best friends</option>
              </select>

              <label style={{fontSize:12, color:'#FFD700', marginTop:16, display:'block'}}>2. STYLE</label>
              <select value={style} onChange={e=>setStyle(e.target.value)} style={{width:'100%', marginTop:8, padding:12, background:'#000', color:'#fff', borderRadius:10, border:'1px solid #333'}}>
                <option>realistic cinematic</option><option>cartoon</option><option>anime</option><option>music video 4K</option><option>hollywood movie</option>
              </select>

              <label style={{fontSize:12, color:'#FFD700', marginTop:16, display:'block'}}>3. EMOTION + TALK (cussing allowed)</label>
              <select value={emotion} onChange={e=>setEmotion(e.target.value)} style={{width:'100%', marginTop:8, padding:12, background:'#000', color:'#fff', borderRadius:10, border:'1px solid #333'}}>
                <option>happy laughing</option><option>angry cussing, shouting fuck</option><option>crying with tears, emotional</option><option>flirting, singing</option><option>arguing, street talk</option><option>singing rap song</option>
              </select>

              <label style={{fontSize:12, color:'#FFD700', marginTop:16, display:'block'}}>4. ACTION (drive, wear brands)</label>
              <input value={action} onChange={e=>setAction(e.target.value)} style={{width:'100%', marginTop:8, padding:12, background:'#000', color:'#fff', borderRadius:10, border:'1px solid #333'}} placeholder="wearing Gucci, driving Lambo"/>

              <label style={{fontSize:12, color:'#FFD700', marginTop:16, display:'block'}}>5. VOICE</label>
              <input value={voice} onChange={e=>setVoice(e.target.value)} style={{width:'100%', marginTop:8, padding:12, background:'#000', color:'#fff', borderRadius:10, border:'1px solid #333'}}/>

              <label style={{fontSize:12, color:'#FFD700', marginTop:16, display:'block'}}>6. DURATION 30sec → 3min</label>
              <select value={duration} onChange={e=>setDuration(parseInt(e.target.value))} style={{width:'100%', marginTop:8, padding:12, background:'#000', color:'#FFD700', borderRadius:10, border:'2px solid #FFD700', fontWeight:800}}>
                <option value={30}>30 SEC - FREE+ADS (250 cr)</option>
                <option value={60}>1 MIN - 500 cr</option>
                <option value={120}>2 MIN - 1000 cr (PRO)</option>
                <option value={180}>3 MIN STORY - 1500 cr (BOSS)</option>
              </select>
            </div>
          </div>

          <div>
            <div className="card" style={{borderColor:'#FFD700'}}>
              <label style={{fontSize:12, color:'#888'}}>STORY - WHAT HAPPENS? (like human)</label>
              <textarea value={story} onChange={e=>setStory(e.target.value)} style={{width:'100%', height:120, marginTop:8, background:'#000', color:'#fff', border:'1px solid #333', borderRadius:12, padding:16, fontSize:15}} placeholder="Example: The talking apple boss and banana argue about who stole the money in Miami mansion, they cuss each other out, then drive G-Wagon singing..."/>
              <button onClick={generate} disabled={loading} className="btn btn-gold" style={{width:'100%', marginTop:16, fontSize:18, padding:18}}>{loading ? 'GABBOSS IS COOKING...' : `GENERATE ${duration}s FOR ${costMap[duration]} CREDITS →`}</button>
              <p style={{fontSize:11, color:'#666', marginTop:10}}>Your Runway: 1000 cr = $10. You charge PRO $19.99 = 100% profit. 3 min uses story mode stitching.</p>
            </div>

            {logs.length>0 && <div className="card" style={{marginTop:16, background:'#000', fontFamily:'monospace', fontSize:12, maxHeight:260, overflowY:'auto'}}>{logs.map((l,i)=><div key={i} style={{marginBottom:4, color: l.includes('Error')?'#f55':'#0f0'}}>{`> ${l}`}</div>)}</div>}

            <div className="card" style={{marginTop:16}}>
              <p style={{fontSize:12, color:'#FFD700'}}>💰 HOW YOU MAKE MONEY WITH YOUR 3000 CREDITS:</p>
              <p style={{fontSize:12, color:'#888', marginTop:8, lineHeight:'20px'}}>
                You have 3000 credits = $30 cost.<br/>
                • Sell 3x PRO $19.99 (1000cr each) = $59.97 → Profit $29.97<br/>
                • Sell 1x PREMIUM $49.99 (3000cr) = $49.99 → Profit $19.99<br/>
                • FREE+ADS: 30 sec videos show Google Ads, you earn $5 per 1000 views, unlimited free users = passive income.<br/>
                Vercel + Stripe takes payment, credits auto-deduct.
              </p>
            </div>
          </div>
        </div>
      )}

      {tab==='videos' && (
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:16}}>
          {videos.length===0 ? <p style={{color:'#666'}}>No videos. Generate your first boss video.</p> : videos.map(v=>(
            <div key={v.id} className="card"><video src={v.url} controls style={{width:'100%', borderRadius:10}}/><p style={{fontSize:12, color:'#888', marginTop:8}}>{v.prompt.slice(0,80)} | {v.duration}s | -{v.cost} cr</p><button className="btn btn-black" style={{width:'100%', marginTop:8}}>DOWNLOAD & SELL ON TIKTOK</button></div>
          ))}
        </div>
      )}

      {tab==='pricing' && (
        <div>
          <h2 style={{fontSize:32, fontWeight:900, marginBottom:20}}>MONETIZE YOUR 3000 CREDITS</h2>
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:20}}>
            <div className="card"><h3>FREE + ADS</h3><p style={{fontSize:36, fontWeight:900}}>$0</p><p style={{color:'#FFD700'}}>30 sec max</p><ul style={{marginTop:12, color:'#888', fontSize:13, lineHeight:'26px'}}><li>✓ 30 sec (250 cr)</li><li>✓ Talking fruits</li><li>✓ Watermark + Ads</li><li>✓ You earn from ads</li></ul><button className="btn btn-black" style={{width:'100%', marginTop:16}}>FREE - WATCH AD</button></div>
            <div className="card" style={{border:'2px solid #FFD700', transform:'scale(1.05)'}}><h3>PRO - MOST POPULAR</h3><p style={{fontSize:36, fontWeight:900}}>$19.99</p><p style={{color:'#0f0'}}>1000 credits</p><p style={{fontSize:11, color:'#666'}}>Cost $10 | Profit $9.99</p><ul style={{marginTop:12, color:'#fff', fontSize:13, lineHeight:'26px'}}><li>✓ 2 MIN movies</li><li>✓ 3 MIN story mode</li><li>✓ No ads, no watermark</li><li>✓ Cussing, emotions, singing</li><li>✓ Drive cars, Gucci, etc</li><li>✓ Sell on TikTok/YT</li></ul><button onClick={()=>{setPlan('PRO'); setCredits(c=>c+1000)}} className="btn btn-gold" style={{width:'100%', marginTop:16}}>BUY PRO $19.99</button></div>
            <div className="card" style={{borderColor:'#FF5500'}}><h3>PREMIUM BOSS</h3><p style={{fontSize:36, fontWeight:900}}>$49.99</p><p style={{color:'#0f0'}}>3000 credits</p><p style={{fontSize:11, color:'#666'}}>Cost $30 | Profit $19.99</p><ul style={{marginTop:12, color:'#888', fontSize:13, lineHeight:'26px'}}><li>✓ 12 min total video</li><li>✓ 3 min x 4 movies</li><li>✓ API access</li><li>✓ Commercial license</li><li>✓ Priority queue</li></ul><button onClick={()=>{setPlan('PREMIUM'); setCredits(c=>c+3000)}} className="btn btn-gold" style={{width:'100%', marginTop:16, background:'#FF5500'}}>BUY PREMIUM $49.99</button></div>
          </div>
          <div className="card" style={{marginTop:30, background:'#111'}}><h4>Setup Stripe in 2 mins:</h4><p style={{fontSize:13, color:'#888', marginTop:8}}>1. Stripe.com → Create Product $19.99 & $49.99 → Copy payment links<br/>2. Vercel → Env vars: STRIPE_PRO_LINK, STRIPE_PREMIUM_LINK<br/>3. When user pays, webhook adds credits automatically (I can add webhook code next)</p></div>
        </div>
      )}
    </div>
  )
}

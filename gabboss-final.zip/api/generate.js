
export default async function handler(req, res){
  if(req.method !== 'POST') return res.status(405).json({error:'POST only'})
  const { fullPrompt, duration } = req.body
  const RUNWAY_API_KEY = process.env.RUNWAY_API_KEY

  if(!RUNWAY_API_KEY){
    return res.status(200).json({
      mock: true,
      videoUrl: '',
      message: 'MOCK MODE - Add RUNWAY_API_KEY in Vercel Settings > Environment Variables. Your 3000 credits will be used here.',
      prompt: fullPrompt
    })
  }

  try{
    // STEP 1: Create Runway task (Gen-3 Turbo)
    // Docs: https://docs.dev.runwayml.com/api/
    const createRes = await fetch('https://api.dev.runwayml.com/v1/text_to_video', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${RUNWAY_API_KEY}`,
        'Content-Type': 'application/json',
        'X-Runway-Version': '2024-11-06'
      },
      body: JSON.stringify({
        promptText: fullPrompt,
        model: 'gen3a_turbo',
        ratio: '1280:720',
        duration: duration <= 30 ? duration : 10 // For 3 min, we generate in 10s chunks
      })
    })

    const task = await createRes.json()
    
    // STEP 2: For MVP, return task ID. In production, poll until done.
    // Polling would be: GET https://api.dev.runwayml.com/v1/tasks/{task.id}
    // Until status === 'SUCCEEDED', then task.output[0]

    return res.status(200).json({
      success: true,
      taskId: task.id || task.task_id || 'mock-task',
      raw: task,
      videoUrl: task.output?.[0] || task.url || '',
      note: duration > 10 ? `Story mode: this is clip 1/${Math.ceil(duration/10)}. Loop this call ${Math.ceil(duration/10)} times to make ${duration}s` : 'Single clip'
    })

  }catch(e){
    return res.status(500).json({error: e.message, mock: true})
  }
}
